# GRASS commands to initialize mapset for Fachprogramm Erosionsberatung
g.mapset -c fpeb 
db.connect -d
exit
